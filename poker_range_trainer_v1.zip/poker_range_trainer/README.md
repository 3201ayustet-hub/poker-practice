# Poker Range Trainer

ポーカー学習用の静的Webアプリです。

## 使い方

1. `index.html` をブラウザで開く
2. プリフロップアクションを回答
3. フロップの有利不利を回答
4. 解説を読む

## 収録内容

- プリフロップ5分類
  - Value
  - Mix Value
  - Mix Bluff
  - Call
  - Fold

- ボード3分類
  - PFR有利
  - BTN/Caller有利
  - ほぼ互角

- 35問入り